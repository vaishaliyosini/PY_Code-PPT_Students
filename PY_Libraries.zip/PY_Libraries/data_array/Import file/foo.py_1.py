import user_1
print (user_1.welcome("quora"))
