def welcome(user_name):
    return "welcome"+ " "+user_name
