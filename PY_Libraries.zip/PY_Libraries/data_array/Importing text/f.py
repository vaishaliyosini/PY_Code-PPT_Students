import numpy as np
data = np.loadtxt('population.txt')
print(data)


np.savetxt('popyyuu.txt', data)
