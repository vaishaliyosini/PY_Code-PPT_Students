from pylab import *
import numpy
x = numpy.random.normal(2, 0.5, 1000)
hist(x, bins=50)
savefig('my_hist')

