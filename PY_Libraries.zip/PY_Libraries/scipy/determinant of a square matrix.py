import numpy as np
from scipy import linalg
arr = np.array([[1, 2],[3, 4]]) #using of square bracket throws error
y=linalg.det(arr)
print(y)
