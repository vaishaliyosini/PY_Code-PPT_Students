#svd
import numpy as np
from scipy import linalg
arr = np.arange(9).reshape((3, 3)) + np.diag([1, 0, 1])
uarr, spec, vharr = linalg.svd(arr)
#The resulting array spectrum is:
print(spec)
#The original matrix can be re-composed by
#matrix multiplication of the outputs of svd with np.dot:
sarr = np.diag(spec)
svd_mat = uarr.dot(sarr).dot(vharr)
u=np.allclose(svd_mat, arr)
print(u)
