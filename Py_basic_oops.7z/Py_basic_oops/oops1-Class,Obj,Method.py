'''
The concept of OOP in Python focuses on creating reusable code.
This concept is also known as DRY (Don't Repeat Yourself).
'''


'''
A class is a blueprint for the object.

We can think of class as an sketch of a parrot with labels.
It contains all the details about the name, colors, size etc.
Based on these descriptions,
we can study about the parrot. Here, parrot is an object.
'''
class parrot:
    pass
    #pass is used when  you dont know what class must contain in it


'''parrot is a object'''

'''An object (instance) is an instantiation of a class.
When class is defined, only the description for the object is defined.
Therefore, no memory or storage is allocated.

'''

'''
defining __init__ is a common practice because instances of a class usually
store some sort of state informtion or data and the methods of the class
offer a way to manipulate or do something with that state information or data.
__init__ allows us to initialize this state information or data while creating
an instance of the class
'''

'''
An instance of the class is always passed as the first argument to a method
of the class. For example if there is class A and you have an instance a = A(),
whenever you call a.foo(x, y), Python calls foo(a, x, y) of class A
automatically. (Note the first argument.)
By convention, we name this first argument as self.
'''
obj = parrot()

class Person: 
  
    # init method or constructor  
    def __init__(self, name): 
        self.name = name 
  
    # Sample Method  
    def say_hi(self): 
        print('Hello, my name is', self.name) 
  
p = Person('vaishu') 
p.say_hi() 
