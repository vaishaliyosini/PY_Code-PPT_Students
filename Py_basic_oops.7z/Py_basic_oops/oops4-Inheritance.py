# parent class
class Bird:
    
    def __init__(self):
        print("Bird is ready")

    def whoisThis(self):
        print("Bird")

    def swim(self):
        print("Swim faster")

# child class
class Penguin(Bird):

    def __init__(self):
        # call super() function
        '''
we use super() function before __init__() method.
This is because we want to pull
the content of __init__() method from the parent class into the child class.'''
        super().__init__()
        print("Penguin is ready")

    def whoisThis(self):
        print("Penguin")

    def run(self):
        print("Run faster")

peggy = Penguin()
'''
Bird is ready
Penguin is ready
'''

peggy.whoisThis()
peggy.swim()
peggy.run()
