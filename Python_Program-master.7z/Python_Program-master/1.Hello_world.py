print("Hello World")
# prints "Hello World"
# above line is a comment
'''
This is a multi-line
comment in python
'''
