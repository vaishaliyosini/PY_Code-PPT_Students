def squared(x):
    return x*x

print (squared(2))   # prints "4"
