# declare an integer
a = 12
print (a)       # prints "12"
print (type(a)) # prints <type 'int'>

# declare a float
b = 1.7
print (b)      # prints "1.7"
print (type(b)) # prints <type 'float'>

# declare a string
c = "Python"
print (c)       # prints "Python"
print (type(c)) # prints <type 'str'>

# declare a boolean
d = True
print (d)       # prints "True" means 1,false means 0
print (type(d)) # prints <type 'bool'>
