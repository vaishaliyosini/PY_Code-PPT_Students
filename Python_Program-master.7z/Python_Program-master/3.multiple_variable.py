# assign values to multiple variables in a single line
a, b, c = 1, 2, 3

# assign values with different data types to multiple variables in a single line
a, b, c = 1, 3.5, "hello"

print (type(a)) # prints <type 'int'>
print (type(b)) # prints <type 'float'>
print (type(c)) # prints <type 'str'>
