a = 10

print (a + 1)  # Addition: prints "11"
print (a - 1)  # Subtraction: prints "9"
print (a * 2)  # Multiplication: prints "20"
print (a / 2)  # Division: prints "5.0"
print (a // 2)  # Division: prints "5"
print (a % 2)  # Division: prints "0" its reminder
print (a**2) # Exponentiation: prints "100"
