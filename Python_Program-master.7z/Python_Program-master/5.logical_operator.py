# declare some boolean variables
x = True
y = False

print (x and y)  # prints "False"
print (x or y)   # prints "True"
print (not x)    # prints "False"
print (x & y)    # prints "False"
