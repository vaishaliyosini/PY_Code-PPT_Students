# while loop
c = 0
while (c < 10):
    print (c,  end='')
    c += 1
print(end='\n')
# prints 0123456789

# while loop
c = 0
while (c <= 10):
    print (c,  end=',')
    c += 1
   
# for loop
numbers = [1, 2, 4]
for x in numbers:
    print (x)

# prints 1
#        2
#        4

x = 5
for c in range(x): #(range prints 0 to (n-1) value.here n is 5)
    print (c)

# prints 0
#        1
#        2
#        3
#        4
