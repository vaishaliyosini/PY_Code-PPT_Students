# Working-Code-on-Python
Here are detail examples for each topic in python. 
